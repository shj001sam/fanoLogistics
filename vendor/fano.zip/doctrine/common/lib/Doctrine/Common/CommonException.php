<?php

namespace Doctrine\Common;

use Exception;

/**
 * Base exception class for package Doctrine\Common.
 *
 * @deprecated The doctrine/common package is deprecated, please use specific packages and their exceptions instead.
 */
class CommonException extends Exception
{
}
