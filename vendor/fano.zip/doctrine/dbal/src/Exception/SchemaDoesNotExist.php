<?php

namespace Doctrine\DBAL\Exception;

/**
 * @psalm-immutable
 */
class SchemaDoesNotExist extends DatabaseObjectNotFoundException
{
}
